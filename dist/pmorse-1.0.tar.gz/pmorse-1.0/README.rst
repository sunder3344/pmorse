# pmorse
morse for python(convert characters to morse code)

get this module by 'pip', like:

pip install morse-for-python

this module also support chinese characters.