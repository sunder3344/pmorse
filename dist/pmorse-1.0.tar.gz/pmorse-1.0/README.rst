# pmorse
morse for python(convert characters to morse code)

get this module by 'pip', like:

pip install pmorse

this module also support chinese characters.